// TP-1: Hello, C!

#include <stdio.h> // Inclusion du fichier d'en-tête pour les fonctions d'entrée/sortie

int main()
{
    printf("Hello, C!"); // Affiche le message "Hello, C!" sur la console
    return 0;            // Indique que le programme s'est terminé avec succès
}
