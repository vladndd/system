// TP-4: Librairies

#include <stdio.h> // les libs predefinis contient des fonctions deja definis ce qui permet de ne pas reecrire le code

int main()
{
    printf("I use stdio.h\n");
    return 0;
}
